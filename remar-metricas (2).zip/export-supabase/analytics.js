/* re.mar · analytics simples -> Supabase (tabela public.eventos)
 *
 * Eventos registrados:
 *   page_view          ao abrir/atualizar a pagina        (origem = de onde veio, ou "direto")
 *   plan_selected      ao escolher Mensal ou Anual         (origem = mensal | anual)
 *   trial_cta_clicked  ao clicar em QUERO TESTAR GRATIS    (origem = secao:plano, ex. hero:anual)
 *   whatsapp_opened    logo antes de abrir o WhatsApp      (origem = secao:plano)
 *   (tambem: clique_gratuito e nivel_* da secao "Como voce quer separar hoje?")
 *
 * Identificador anonimo (visitor_id):
 *   UUID aleatorio gerado no navegador e guardado em localStorage ("remar_vid").
 *   Serve so para estimar visitantes unicos. Nao ha nome, telefone, e-mail, IP
 *   coletado de proposito nem localizacao. Vai junto com cada evento.
 *
 * Regras: nunca lanca erro e nunca espera resposta (fire-and-forget), entao um problema
 * no registro NAO impede o site nem a abertura do WhatsApp. Usa so o INSERT permitido
 * ao papel anon (Prefer: return=minimal, sem "upsert").
 * Chaves: window.REMAR_CONFIG (config.js).
 */
(function () {
  var W = window;
  var CHAVE_ID = 'remar_vid';
  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  var vid = null;

  function conf() {
    var c = W.REMAR_CONFIG || {};
    return { url: String(c.supabaseUrl || '').replace(/\/$/, ''), key: String(c.supabaseAnonKey || '') };
  }

  function aviso(msg, extra) {
    try { if (W.console && W.console.warn) W.console.warn('[re.mar analytics] ' + msg, extra || ''); } catch (e) {}
  }

  // UUID v4 aleatorio (crypto.randomUUID; se nao existir, getRandomValues; ultimo recurso, Math.random)
  function novoUuid() {
    try { if (W.crypto && typeof W.crypto.randomUUID === 'function') return W.crypto.randomUUID(); } catch (e) {}
    var b = [], i;
    try {
      if (W.crypto && W.crypto.getRandomValues) { b = Array.prototype.slice.call(W.crypto.getRandomValues(new Uint8Array(16))); }
    } catch (e) { b = []; }
    if (b.length !== 16) { b = []; for (i = 0; i < 16; i++) b.push(Math.floor(Math.random() * 256)); }
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    var h = b.map(function (n) { return (n < 16 ? '0' : '') + n.toString(16); }).join('');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
  }

  // Reaproveita o id deste navegador; cria e guarda se ainda nao existir.
  // Se o navegador bloquear o armazenamento, o id vale so ate fechar a pagina.
  function visitorId() {
    if (vid) return vid;
    try {
      var salvo = W.localStorage.getItem(CHAVE_ID);
      if (salvo && UUID_RE.test(salvo)) { vid = salvo; return vid; }
    } catch (e) {}
    vid = novoUuid();
    try { W.localStorage.setItem(CHAVE_ID, vid); } catch (e) {}
    return vid;
  }

  function enviar(c, corpo, tipo, podeTentarSemId) {
    var p = fetch(c.url + '/rest/v1/eventos', {
      method: 'POST',
      keepalive: true,
      headers: {
        'Content-Type': 'application/json',
        apikey: c.key,
        Authorization: 'Bearer ' + c.key,
        Prefer: 'return=minimal'
      },
      body: JSON.stringify(corpo)
    });
    if (p && typeof p.then === 'function') {
      p.then(
        function (r) {
          if (r.ok) return;
          // Se a coluna visitor_id ainda nao existe no banco (400), grava o evento sem ela
          // para nao perder a metrica.
          if (r.status === 400 && podeTentarSemId && corpo.visitor_id) {
            var sem = { tipo: corpo.tipo, origem: corpo.origem };
            enviar(c, sem, tipo, false);
            return;
          }
          aviso('Supabase respondeu ' + r.status + ' ao registrar ' + tipo);
        },
        function (e) { aviso('falha de rede ao registrar ' + tipo, e); }
      ).then(null, function () {});
    }
  }

  function track(tipo, origem) {
    try {
      var c = conf();
      if (!c.url || !c.key) { aviso('supabaseUrl/supabaseAnonKey ausentes em config.js; evento nao enviado:', tipo); return; }
      var corpo = { tipo: String(tipo), origem: String(origem == null ? '' : origem).slice(0, 200), visitor_id: visitorId() };
      enviar(c, corpo, tipo, true);
    } catch (e) { aviso('erro ao registrar ' + tipo, e); }
  }

  W.remarTrack = track;
  W.remarVisitorId = visitorId;

  // page_view: a cada abertura/atualizacao da pagina (visualizacoes);
  // visitantes unicos = ids diferentes.
  track('page_view', (document.referrer || '').slice(0, 200) || 'direto');
})();
